#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    vec3 pos = Position;
#if defined(IS_GUI)
    // TUSB NEO：tusb_fx の効果の表示（アクションバー、色 #F05848 とその影 #3C1612）だけを、画面の下（体力の段と重なる）から
    // 上から 22% の所へ上げる（データパック tusb:legacy/fx_show。11-19）。GUI の高さは正射影の ProjMat[1][1] = -2/高さ から
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    // 普通の赤（#FF5555、影 #3F1515）などと重ならない色にして、ぴったり同じ色だけを動かす（11-19：ゆるくしたらマップの赤い文字まで動いた）
    if (c == ivec3(240, 88, 72) || c == ivec3(60, 22, 18)) {
        float h = -2.0 / ProjMat[1][1];
        if (h > 0.0 && pos.y > h - 90.0) {
            pos.y += h * 0.22 - (h - 68.0);
        }
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
